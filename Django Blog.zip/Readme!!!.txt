README
---------------------
Django Administration

User name : admin
passowrd : task123456

---------------------

normal user 
User name : User1
Passowrd : Technicaltask123

----------------------------
